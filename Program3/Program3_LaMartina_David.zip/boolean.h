/* David LaMartina
 * lamartid@oregonstate.edu
 * Utilities for Program 3: smallsh
 * CS344 Spr2019
 * Due May 26, 2019
 */

#ifndef BOOLEAN_H
#define BOOLEAN_H

enum boolean { FALSE, TRUE };

#endif
